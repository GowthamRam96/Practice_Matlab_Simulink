%% This script initializes the lab
% This file automatically runs when you open the project

%% Show the info script
open("Info.html")


