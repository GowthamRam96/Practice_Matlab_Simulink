Simple examples how one can create 
gui-applications without Guide
or with more simple using Guide

We use nested functions. 
So this will work only for Matlab 7.0+

gui01.m 3 buttons (PushButton, ToggleButton)

gui02.m 3 buttons with more sofisticated CallBack routines

gui03.m dynamic StaticText

gui04.m RadioButtons

gui05.m CheckBoxes

gui06.m ListBox and PopupMenu

gui07.m Edit and Slider

gui08.m uimenu

gui09.m uicontextmenu

gui10.m uicontextmenu with CallBack routines

gui11.m drawing asteriskes (buttondownfcn)

gui12.m drawing, moving and deleting asteriskes 
        (windowbuttondownfcn, windowbuttonupfcn, windowbuttonmotionfcn)

msr.m  this example shows how create gui application using 
       Guide without Guide's prototypes of M-file 
       (Tick 'Generate Fig file only' in Guide's Tools|Gui Options)

Nikolai Yu. Zolotykh
08.08.2005
zny@uic.nnov.ru
